package com.cs360.projecttwo;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.cs360.projecttwo.ItemRepository;
import com.cs360.projecttwo.ItemCreateDto;
import com.cs360.projecttwo.ItemDto;

public class AddItemActivity extends AppCompatActivity {

    private EditText nameEditText, typeEditText, quantityEditText, descriptionEditText;
    private Button saveButton;
    private ItemRepository itemRepo;
    private long userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        nameEditText = findViewById(R.id.nameEditText);
        typeEditText = findViewById(R.id.typeEditText);
        quantityEditText = findViewById(R.id.quantityEditText);
        descriptionEditText = findViewById(R.id.descriptionEditText);
        saveButton = findViewById(R.id.saveButton);

        itemRepo = new ItemRepository();
        userId = getSharedPreferences("app", MODE_PRIVATE).getLong("userId", -1L);

        if (userId == -1L) {
            Toast.makeText(this, "No logged-in user found.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addItem();
            }
        });
    }

    // Add a new item via backend
    private void addItem() {
        String name = nameEditText.getText().toString().trim();
        String type = typeEditText.getText().toString().trim();
        String description = descriptionEditText.getText().toString().trim();
        String qtyText = quantityEditText.getText().toString().trim();

        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(type) || TextUtils.isEmpty(description) || TextUtils.isEmpty(qtyText)) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        int qty;
        try {
            qty = Integer.parseInt(qtyText);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Quantity must be a number", Toast.LENGTH_SHORT).show();
            return;
        }

        ItemCreateDto dto = new ItemCreateDto(userId, name, type, qty, description);

        itemRepo.create(dto, new ItemRepository.Result<ItemDto>() {
            @Override
            public void onSuccess(ItemDto result) {
                Toast.makeText(AddItemActivity.this, "Item added successfully", Toast.LENGTH_SHORT).show();
                finish(); // return to MainActivity
            }

            @Override
            public void onError(Throwable t, Integer httpCode) {
                Toast.makeText(AddItemActivity.this, "Error adding item", Toast.LENGTH_SHORT).show();
            }
        });
    }
}

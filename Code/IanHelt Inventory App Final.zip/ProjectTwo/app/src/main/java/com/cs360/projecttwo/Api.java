package com.cs360.projecttwo;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public final class Api {
    private static volatile Retrofit retrofit;
    private static volatile ItemApi itemApi;  // kept for compatibility
    private static volatile UserApi userApi;  // new

    private static String BASE_URL = "http://10.0.2.2:8080/";

    private Api() {}

    private static Retrofit retrofit() {
        if (retrofit == null) {
            synchronized (Api.class) {
                if (retrofit == null) {
                    HttpLoggingInterceptor log = new HttpLoggingInterceptor();
                    log.setLevel(HttpLoggingInterceptor.Level.BODY);

                    OkHttpClient client = new OkHttpClient.Builder()
                            .addInterceptor(log)
                            .build();

                    retrofit = new Retrofit.Builder()
                            .baseUrl(BASE_URL)
                            .addConverterFactory(GsonConverterFactory.create())
                            .client(client)
                            .build();
                }
            }
        }
        return retrofit;
    }

    public static ItemApi get() {
        if (itemApi == null) {
            synchronized (Api.class) {
                if (itemApi == null) {
                    itemApi = retrofit().create(ItemApi.class);
                }
            }
        }
        return itemApi;
    }

    public static ItemApi items() {
        return get();
    }

    public static UserApi users() {
        if (userApi == null) {
            synchronized (Api.class) {
                if (userApi == null) {
                    userApi = retrofit().create(UserApi.class);
                }
            }
        }
        return userApi;
    }

    public static synchronized void setBaseUrl(String baseUrl) {
        if (retrofit != null) {
            throw new IllegalStateException("Base URL must be set before first use of Api.");
        }
        BASE_URL = baseUrl.endsWith("/") ? baseUrl : baseUrl + "/";
    }
}

package com.cs360.projecttwo;


// UI model representing an inventory item for display in the app.
// Populated from ItemDto (fetched from backend).
public class Item {

    private long id;
    private String name;
    private String type;
    private int quantity;
    private String description;

    public Item(long id, String name, String type, int quantity, String description) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.quantity = quantity;
        this.description = description;
    }

    // Getters
    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getDescription() {
        return description;
    }

    // Setters
    public void setId(long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    // Utility
    @Override
    public String toString() {
        return "Item{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", type='" + type + '\'' +
                ", qty=" + quantity +
                ", description='" + description + '\'' +
                '}';
    }
}

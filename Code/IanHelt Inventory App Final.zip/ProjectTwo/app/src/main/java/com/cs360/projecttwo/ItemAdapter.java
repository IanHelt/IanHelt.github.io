package com.cs360.projecttwo;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

// Connects Item data to the RecyclerView grid
public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ItemViewHolder> {

    private List<Item> itemList;
    private final OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(Item item);
    }

    public ItemAdapter(List<Item> itemList, OnItemClickListener listener) {
        this.itemList = itemList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_grid, parent, false);
        return new ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        final Item item = itemList.get(position);

        holder.nameTextView.setText(item.getName());
        holder.typeTextView.setText(item.getType());
        holder.quantityTextView.setText(String.valueOf(item.getQuantity()));
        holder.descriptionTextView.setText(item.getDescription());

        holder.itemView.setOnClickListener(v -> listener.onItemClick(item));
    }

    @Override
    public int getItemCount() {
        return itemList != null ? itemList.size() : 0;
    }

    // Allows updating the list after network refresh
    public void setItems(List<Item> newItems) {
        this.itemList = newItems;
        notifyDataSetChanged();
    }

    // ViewHolder binds each item layout to its views
    public static class ItemViewHolder extends RecyclerView.ViewHolder {
        final TextView nameTextView, typeTextView, quantityTextView, descriptionTextView;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.nameTextView);
            typeTextView = itemView.findViewById(R.id.typeTextView);
            quantityTextView = itemView.findViewById(R.id.quantityTextView);
            descriptionTextView = itemView.findViewById(R.id.descriptionTextView);
        }
    }
}

package com.cs360.projecttwo;

import com.cs360.projecttwo.ItemCreateDto;
import com.cs360.projecttwo.ItemDto;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.*;

public interface ItemApi {
    @GET("api/items")
    Call<List<ItemDto>> list(@Query("userId") long userId);

    @GET("api/items/{id}")
    Call<ItemDto> get(@Path("id") long id);

    @POST("api/items")
    Call<ItemDto> create(@Body ItemCreateDto body);

    @PUT("api/items/{id}")
    Call<ItemDto> update(@Path("id") long id, @Body ItemCreateDto body);

    @DELETE("api/items/{id}")
    Call<Void> delete(@Path("id") long id);
}

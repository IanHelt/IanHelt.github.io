package com.cs360.projecttwo;

public class ItemCreateDto {
    public Long userId;
    public String name;
    public String type;
    public Integer qty;
    public String description;

    public ItemCreateDto(Long userId, String name, String type, Integer qty, String description) {
        this.userId = userId;
        this.name = name;
        this.type = type;
        this.qty = qty;
        this.description = description;
    }
}

package com.cs360.projecttwo;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ItemDetailActivity extends AppCompatActivity {

    private EditText nameEditText, typeEditText, quantityEditText, descriptionEditText;
    private Button updateButton, deleteButton;
    private long itemId;

    private ItemRepository itemRepo;
    private long userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_detail);

        nameEditText = findViewById(R.id.nameEditText);
        typeEditText = findViewById(R.id.typeEditText);
        quantityEditText = findViewById(R.id.quantityEditText);
        descriptionEditText = findViewById(R.id.descriptionEditText);
        updateButton = findViewById(R.id.updateButton);
        deleteButton = findViewById(R.id.deleteButton);

        itemRepo = new ItemRepository();

        // Load stored userId (set during login/register)
        userId = getSharedPreferences("app", MODE_PRIVATE).getLong("userId", -1L);

        // Get item ID passed from MainActivity
        itemId = getIntent().getLongExtra("itemId", -1);

        if (itemId == -1L) {
            Toast.makeText(this, "Invalid item ID", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        loadItemDetails();

        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateItem();
            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteItem();
            }
        });
    }

    // Load the item details from backend
    private void loadItemDetails() {
        itemRepo.get(itemId, new ItemRepository.Result<ItemDto>() {
            @Override
            public void onSuccess(ItemDto dto) {
                nameEditText.setText(dto.name);
                typeEditText.setText(dto.type);
                quantityEditText.setText(String.valueOf(dto.qty));
                descriptionEditText.setText(dto.description);
            }

            @Override
            public void onError(Throwable t, Integer httpCode) {
                Toast.makeText(ItemDetailActivity.this, "Failed to load item", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }

    // Update the item through backend
    private void updateItem() {
        String name = nameEditText.getText().toString().trim();
        String type = typeEditText.getText().toString().trim();
        String desc = descriptionEditText.getText().toString().trim();
        int qty;

        try {
            qty = Integer.parseInt(quantityEditText.getText().toString().trim());
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Quantity must be a number", Toast.LENGTH_SHORT).show();
            return;
        }

        ItemCreateDto update = new ItemCreateDto(userId, name, type, qty, desc);

        itemRepo.update(itemId, update, new ItemRepository.Result<ItemDto>() {
            @Override
            public void onSuccess(ItemDto value) {
                Toast.makeText(ItemDetailActivity.this, "Item updated successfully", Toast.LENGTH_SHORT).show();
                finish();
            }

            @Override
            public void onError(Throwable t, Integer httpCode) {
                Toast.makeText(ItemDetailActivity.this, "Error updating item", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Delete the item through backend
    private void deleteItem() {
        itemRepo.delete(itemId, new ItemRepository.Result<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Toast.makeText(ItemDetailActivity.this, "Item deleted", Toast.LENGTH_SHORT).show();
                finish();
            }

            @Override
            public void onError(Throwable t, Integer httpCode) {
                Toast.makeText(ItemDetailActivity.this, "Error deleting item", Toast.LENGTH_SHORT).show();
            }
        });
    }
}

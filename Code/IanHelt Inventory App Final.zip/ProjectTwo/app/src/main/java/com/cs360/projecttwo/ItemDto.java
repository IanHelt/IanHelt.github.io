package com.cs360.projecttwo;

public class ItemDto {
    public Long id;
    public Long userId;
    public String name;
    public String type;
    public Integer qty;
    public String description;
}

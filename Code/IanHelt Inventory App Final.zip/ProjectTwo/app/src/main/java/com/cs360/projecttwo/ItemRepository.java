package com.cs360.projecttwo;

import androidx.annotation.Nullable;

import com.cs360.projecttwo.Api;
import com.cs360.projecttwo.ItemApi;
import com.cs360.projecttwo.ItemCreateDto;
import com.cs360.projecttwo.ItemDto;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

// Repository for CRUD operations on items via the backend REST API.
public class ItemRepository {

    public interface Result<T> {
        void onSuccess(T value);
        void onError(Throwable t, @Nullable Integer httpCode);
    }

    private final ItemApi api = Api.get();

    // Fetch all items for a specific user
    public void list(long userId, Result<List<ItemDto>> cb) {
        api.list(userId).enqueue(new Callback<List<ItemDto>>() {
            @Override
            public void onResponse(Call<List<ItemDto>> call, Response<List<ItemDto>> resp) {
                if (resp.isSuccessful() && resp.body() != null) {
                    cb.onSuccess(resp.body());
                } else {
                    cb.onError(new RuntimeException("List failed"), resp.code());
                }
            }

            @Override
            public void onFailure(Call<List<ItemDto>> call, Throwable t) {
                cb.onError(t, null);
            }
        });
    }

    // Create a new item
    public void create(ItemCreateDto body, Result<ItemDto> cb) {
        api.create(body).enqueue(new Callback<ItemDto>() {
            @Override
            public void onResponse(Call<ItemDto> call, Response<ItemDto> resp) {
                if (resp.isSuccessful() && resp.body() != null) {
                    cb.onSuccess(resp.body());
                } else {
                    cb.onError(new RuntimeException("Create failed"), resp.code());
                }
            }

            @Override
            public void onFailure(Call<ItemDto> call, Throwable t) {
                cb.onError(t, null);
            }
        });
    }

    // Fetch a single item by ID
    public void get(long id, Result<ItemDto> cb) {
        api.get(id).enqueue(new Callback<ItemDto>() {
            @Override
            public void onResponse(Call<ItemDto> call, Response<ItemDto> resp) {
                if (resp.isSuccessful() && resp.body() != null) {
                    cb.onSuccess(resp.body());
                } else {
                    cb.onError(new RuntimeException("Get failed"), resp.code());
                }
            }

            @Override
            public void onFailure(Call<ItemDto> call, Throwable t) {
                cb.onError(t, null);
            }
        });
    }

    // Update an existing item by id
    public void update(long id, ItemCreateDto body, Result<ItemDto> cb) {
        api.update(id, body).enqueue(new Callback<ItemDto>() {
            @Override
            public void onResponse(Call<ItemDto> call, Response<ItemDto> resp) {
                if (resp.isSuccessful() && resp.body() != null) {
                    cb.onSuccess(resp.body());
                } else {
                    cb.onError(new RuntimeException("Update failed"), resp.code());
                }
            }

            @Override
            public void onFailure(Call<ItemDto> call, Throwable t) {
                cb.onError(t, null);
            }
        });
    }

    // Delete an item by id
    public void delete(long id, Result<Void> cb) {
        api.delete(id).enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> resp) {
                if (resp.isSuccessful()) {
                    cb.onSuccess(null);
                } else {
                    cb.onError(new RuntimeException("Delete failed"), resp.code());
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                cb.onError(t, null);
            }
        });
    }
}

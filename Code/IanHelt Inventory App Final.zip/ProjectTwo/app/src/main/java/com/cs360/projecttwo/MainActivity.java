package com.cs360.projecttwo;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Toast;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private Button addItemButton, settingsButton;
    private ItemAdapter itemAdapter;
    private ArrayList<Item> itemList;
    private Spinner sortSpinner;
    private String[] sortOptions = new String[]{
            "Name (A–Z)", "Type (A–Z)", "Quantity (Low-High)"
    };
    private int currentSortIndex = 0;
    private static final int REQUEST_SMS_PERMISSION = 123;

    private ItemRepository itemRepo;
    private long userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        addItemButton = findViewById(R.id.addItemButton);
        settingsButton = findViewById(R.id.settingsButton);
        sortSpinner = findViewById(R.id.sortSpinner);
        itemList = new ArrayList<>();
        itemRepo = new ItemRepository();

        // Load stored userId from login
        userId = getSharedPreferences("app", MODE_PRIVATE).getLong("userId", -1L);
        if (userId == -1L) {
            Toast.makeText(this, "No logged-in user found.", Toast.LENGTH_LONG).show();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        // Adapter for the spinner
        ArrayAdapter<String> sortAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                sortOptions
        );
        sortAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sortSpinner.setAdapter(sortAdapter);

        sortSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                currentSortIndex = position;
                applySort(); // run sorting function
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // do nothing or reset sort
            }
        });

        // Set up RecyclerView
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        itemAdapter = new ItemAdapter(itemList, item -> {
            Intent intent = new Intent(MainActivity.this, ItemDetailActivity.class);
            intent.putExtra("itemId", item.getId());
            startActivity(intent);
        });
        recyclerView.setAdapter(itemAdapter);

        requestSmsPermission();
        loadItemsFromServer();

        addItemButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddItemActivity.class);
            startActivity(intent);
        });

        settingsButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
            startActivity(intent);
        });
    }

    // Fetch all items for this user from backend via Retrofit
    private void loadItemsFromServer() {
        itemRepo.list(userId, new ItemRepository.Result<List<ItemDto>>() {
            @Override
            public void onSuccess(List<ItemDto> items) {
                itemList.clear();
                for (ItemDto dto : items) {
                    String desc = (dto.description != null) ? dto.description : "";
                    String shortDesc = (desc.length() > 30) ? desc.substring(0, 30) + "..." : desc;

                    // prevent null int crash
                    int safeQty = (dto.qty != null) ? dto.qty : 0;

                    itemList.add(new Item(dto.id, dto.name, dto.type, safeQty, shortDesc));
                }
                applySort();          // sort based on current spinner selection
                checkItemQuantities();
            }

            @Override
            public void onError(Throwable t, Integer httpCode) {
                Toast.makeText(MainActivity.this, "Failed to load items.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{android.Manifest.permission.SEND_SMS},
                    REQUEST_SMS_PERMISSION
            );
        }
    }

    // Checks for low quantities in the loaded list
    private void checkItemQuantities() {
        SharedPreferences sharedPreferences = getSharedPreferences("AppSettings", MODE_PRIVATE);
        boolean notificationsEnabled = sharedPreferences.getBoolean("notificationsEnabled", false);
        int notificationThreshold = sharedPreferences.getInt("notificationThreshold", 0);
        String phoneNumber = sharedPreferences.getString("notificationPhoneNumber", "");

        if (!notificationsEnabled || phoneNumber.isEmpty()) return;

        for (Item item : itemList) {
            if (item.getQuantity() < notificationThreshold) {
                String message = "Alert: Item '" + item.getName() +
                        "' is low on stock. Current qty: " + item.getQuantity();
                sendSms(phoneNumber, message);
            }
        }
    }

    private void sendSms(String phoneNumber, String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "Low stock SMS sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS sending failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadItemsFromServer();  // reload latest items when coming back
    }

    private void applySort() {
        if (itemList == null || itemList.isEmpty()) {
            itemAdapter.notifyDataSetChanged();
            return;
        }

        switch (currentSortIndex) {
            case 0: // Name (A–Z)
                Collections.sort(itemList, (a, b) -> safe(a.getName()).compareToIgnoreCase(safe(b.getName())));
                break;
            case 1: // Type (A–Z)
                Collections.sort(itemList, (a, b) -> safe(a.getType()).compareToIgnoreCase(safe(b.getType())));
                break;
            case 2: // Quantity (Low→High)
                Collections.sort(itemList, Comparator.comparingInt(Item::getQuantity));
                break;
        }
        itemAdapter.notifyDataSetChanged();
    }

    private String safe(String s) { return (s == null) ? "" : s; }
}
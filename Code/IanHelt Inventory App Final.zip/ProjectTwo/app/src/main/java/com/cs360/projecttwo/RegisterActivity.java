package com.cs360.projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.cs360.projecttwo.UserRepository;
import com.cs360.projecttwo.UserDto;

public class RegisterActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button registerButton;

    private UserRepository users;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        registerButton = findViewById(R.id.registerButton);

        users = new UserRepository();

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                attemptRegistration();
            }
        });
    }

    private void attemptRegistration() {
        final String username = usernameEditText.getText().toString().trim();
        final String password = passwordEditText.getText().toString().trim();

        if (TextUtils.isEmpty(username)) {
            usernameEditText.setError("Username is required");
            return;
        }

        if (TextUtils.isEmpty(password)) {
            passwordEditText.setError("Password is required");
            return;
        }

        // Call backend to create user
        users.create(username, password, new UserRepository.Result<UserDto>() {
            @Override
            public void onSuccess(UserDto u) {
                // Save user info locally for automatic login
                getSharedPreferences("app", MODE_PRIVATE)
                        .edit()
                        .putLong("userId", u.id)
                        .putString("username", u.username)
                        .apply();

                Toast.makeText(RegisterActivity.this,
                        "Registration successful! Logged in as " + u.username,
                        Toast.LENGTH_SHORT).show();

                // Go straight to MainActivity
                Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }

            @Override
            public void onError(Throwable t, Integer httpCode) {
                String msg;
                if (httpCode != null && httpCode == 409) {
                    msg = "Username already exists";
                } else {
                    msg = "Registration failed. Please try again.";
                }
                Toast.makeText(RegisterActivity.this, msg, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
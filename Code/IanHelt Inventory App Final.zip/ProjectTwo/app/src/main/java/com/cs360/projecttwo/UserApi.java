package com.cs360.projecttwo;

import com.cs360.projecttwo.UserDto;
import com.cs360.projecttwo.UserCreateDto;

import retrofit2.Call;
import retrofit2.http.*;

public interface UserApi {
    @POST("api/users/login")
    Call<UserDto> login(@Body UserCreateDto body);

    @POST("api/users")
    Call<UserDto> create(@Body UserCreateDto body);

    @GET("api/users/{id}")
    Call<UserDto> get(@Path("id") Long id);

    @GET("api/users/by-username/{username}")
    Call<UserDto> getByUsername(@Path("username") String username);
}

package com.cs360.projecttwo;

public class UserCreateDto {
    public String username;
    public String password;

    public UserCreateDto(String username, String password) {
        this.username = username;
        this.password = password;
    }
}

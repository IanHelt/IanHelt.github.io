package com.cs360.projecttwo;

public class UserDto {
    public Long id;
    public String username;
}

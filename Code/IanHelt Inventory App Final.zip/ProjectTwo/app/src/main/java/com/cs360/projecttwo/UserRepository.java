package com.cs360.projecttwo;

import androidx.annotation.Nullable;

import com.cs360.projecttwo.Api;
import com.cs360.projecttwo.UserApi;
import com.cs360.projecttwo.UserCreateDto;
import com.cs360.projecttwo.UserDto;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

// Repository for managing User API interactions
public class UserRepository {

    public interface Result<T> {
        void onSuccess(T value);
        void onError(Throwable t, @Nullable Integer httpCode);
    }

    private final UserApi api = Api.users();

    // Register a new user
    public void create(String username, String password, Result<UserDto> cb) {
        api.create(new UserCreateDto(username, password)).enqueue(new Callback<UserDto>() {
            @Override
            public void onResponse(Call<UserDto> call, Response<UserDto> resp) {
                if (resp.isSuccessful() && resp.body() != null) {
                    cb.onSuccess(resp.body());
                } else {
                    cb.onError(new RuntimeException("Create user failed"), resp.code());
                }
            }

            @Override
            public void onFailure(Call<UserDto> call, Throwable t) {
                cb.onError(t, null);
            }
        });
    }

    // Log in an existing user
    public void login(String username, String password, Result<UserDto> cb) {
        api.login(new UserCreateDto(username, password)).enqueue(new Callback<UserDto>() {
            @Override
            public void onResponse(Call<UserDto> call, Response<UserDto> resp) {
                if (resp.isSuccessful() && resp.body() != null) {
                    cb.onSuccess(resp.body());
                } else if (resp.code() == 401) {
                    cb.onError(new RuntimeException("Invalid password"), resp.code());
                } else if (resp.code() == 404) {
                    cb.onError(new RuntimeException("User not found"), resp.code());
                } else {
                    cb.onError(new RuntimeException("Login failed: " + resp.code()), resp.code());
                }
            }

            @Override
            public void onFailure(Call<UserDto> call, Throwable t) {
                cb.onError(t, null);
            }
        });
    }

    // Get user by ID
    public void getById(long id, Result<UserDto> cb) {
        api.get(id).enqueue(new Callback<UserDto>() {
            @Override
            public void onResponse(Call<UserDto> call, Response<UserDto> resp) {
                if (resp.isSuccessful() && resp.body() != null) {
                    cb.onSuccess(resp.body());
                } else {
                    cb.onError(new RuntimeException("Get user failed"), resp.code());
                }
            }

            @Override
            public void onFailure(Call<UserDto> call, Throwable t) {
                cb.onError(t, null);
            }
        });
    }
}

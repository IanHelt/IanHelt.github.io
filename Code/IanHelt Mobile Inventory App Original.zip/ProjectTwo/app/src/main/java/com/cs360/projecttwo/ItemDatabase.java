package com.cs360.projecttwo;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ItemDatabase extends SQLiteOpenHelper {

    // Database Name and Version
    private static final String DATABASE_NAME = "InventoryDB";
    private static final int DATABASE_VERSION = 1;

    // Table Name
    public static final String TABLE_ITEMS = "items";

    // Columns
    public static final String COL_ID = "_id";
    public static final String COL_NAME = "name";
    public static final String COL_TYPE = "type";
    public static final String COL_QUANTITY = "quantity";
    public static final String COL_DESCRIPTION = "description";

    // SQL query to create the item table
    private static final String TABLE_CREATE =
            "CREATE TABLE " + TABLE_ITEMS + " (" +
                    COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_NAME + " TEXT, " +
                    COL_TYPE + " TEXT, " +
                    COL_QUANTITY + " INTEGER, " +
                    COL_DESCRIPTION + " TEXT);";

    public ItemDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ITEMS);
        onCreate(db);
    }

    // Add a new item
    public long addItem(String name, String type, int quantity, String description) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_NAME, name);
        values.put(COL_TYPE, type);
        values.put(COL_QUANTITY, quantity);
        values.put(COL_DESCRIPTION, description);
        long result = db.insert(TABLE_ITEMS, null, values);
        db.close();
        return result;
    }

    // Get all items
    public Cursor getAllItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_ITEMS, null);
    }

    // Get a specific item by ID
    public Cursor getItemById(long id) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_ITEMS + " WHERE " + COL_ID + "=" + id, null);
    }

    // Update an item
    public int updateItem(long id, String name, String type, int quantity, String description) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_NAME, name);
        values.put(COL_TYPE, type);
        values.put(COL_QUANTITY, quantity);
        values.put(COL_DESCRIPTION, description);
        return db.update(TABLE_ITEMS, values, COL_ID + "=?", new String[]{String.valueOf(id)});
    }

    // Delete an item
    public int deleteItem(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_ITEMS, COL_ID + "=?", new String[]{String.valueOf(id)});
    }
}

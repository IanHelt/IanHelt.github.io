package com.cs360.projecttwo;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ItemDetailActivity extends AppCompatActivity {

    private EditText nameEditText, typeEditText, quantityEditText, descriptionEditText;
    private Button updateButton, deleteButton;
    private ItemDatabase itemDatabase;
    private long itemId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_detail);

        nameEditText = findViewById(R.id.nameEditText);
        typeEditText = findViewById(R.id.typeEditText);
        quantityEditText = findViewById(R.id.quantityEditText);
        descriptionEditText = findViewById(R.id.descriptionEditText);
        updateButton = findViewById(R.id.updateButton);
        deleteButton = findViewById(R.id.deleteButton);

        itemDatabase = new ItemDatabase(this);

        // Get the item ID passed from MainActivity
        itemId = getIntent().getLongExtra("itemId", -1);

        // Load the item details into the EditTexts
        loadItemDetails();

        // Update the item when the button is clicked
        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateItem();
            }
        });

        // Delete the item when the button is clicked
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteItem();
            }
        });
    }

    // Load the item details from the database
    private void loadItemDetails() {
        // Ensure the itemId is valid before proceeding
        if (itemId == -1) {
            Toast.makeText(this, "Invalid item ID", Toast.LENGTH_SHORT).show();
            finish();  // Go back if the itemId is invalid
            return;
        }

        Cursor cursor = itemDatabase.getItemById(itemId);

        // Ensure the cursor is not null and has valid data
        if (cursor != null && cursor.moveToFirst()) {
            String name = cursor.getString(cursor.getColumnIndexOrThrow(ItemDatabase.COL_NAME));
            String type = cursor.getString(cursor.getColumnIndexOrThrow(ItemDatabase.COL_TYPE));
            int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(ItemDatabase.COL_QUANTITY));
            String description = cursor.getString(cursor.getColumnIndexOrThrow(ItemDatabase.COL_DESCRIPTION));

            nameEditText.setText(name);
            typeEditText.setText(type);
            quantityEditText.setText(String.valueOf(quantity));
            descriptionEditText.setText(description);

            cursor.close();
        } else {
            // Handle the case where the item was not found
            Toast.makeText(this, "Item not found", Toast.LENGTH_SHORT).show();
            finish();  // Go back to the previous screen if the item is not found
        }
    }

    // Update the item in the database
    private void updateItem() {
        String name = nameEditText.getText().toString().trim();
        String type = typeEditText.getText().toString().trim();
        int quantity = Integer.parseInt(quantityEditText.getText().toString().trim());
        String description = descriptionEditText.getText().toString().trim();

        if (itemDatabase.updateItem(itemId, name, type, quantity, description) > 0) {
            Toast.makeText(ItemDetailActivity.this, "Item updated successfully", Toast.LENGTH_SHORT).show();
            finish();  // Return to MainActivity
        } else {
            Toast.makeText(ItemDetailActivity.this, "Error updating item", Toast.LENGTH_SHORT).show();
        }
    }

    // Delete the item from the database
    private void deleteItem() {
        if (itemDatabase.deleteItem(itemId) > 0) {
            Toast.makeText(ItemDetailActivity.this, "Item deleted", Toast.LENGTH_SHORT).show();
            finish();  // Return to MainActivity
        } else {
            Toast.makeText(ItemDetailActivity.this, "Error deleting item", Toast.LENGTH_SHORT).show();
        }
    }
}

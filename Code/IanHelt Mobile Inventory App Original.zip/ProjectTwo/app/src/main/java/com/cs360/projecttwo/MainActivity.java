package com.cs360.projecttwo;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private Button addItemButton, settingsButton;
    private ItemAdapter itemAdapter;
    private ItemDatabase itemDatabase;
    private ArrayList<Item> itemList;
    private static final int REQUEST_SMS_PERMISSION = 123;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        addItemButton = findViewById(R.id.addItemButton);
        settingsButton = findViewById(R.id.settingsButton);
        itemDatabase = new ItemDatabase(this);
        itemList = new ArrayList<>();

        // Fetch all items from the database
        loadItemsFromDatabase();
        // Requests permission to utilize SMS messages if enabled
        requestSmsPermission();
        // Checks for low quantities on startup
        checkItemQuantities();

        // Set up the RecyclerView with a grid layout
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        itemAdapter = new ItemAdapter(itemList, new ItemAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Item item) {
                // Open the detail activity when an item is clicked
                Intent intent = new Intent(MainActivity.this, ItemDetailActivity.class);
                intent.putExtra("itemId", item.getId());
                startActivity(intent);
            }
        });
        recyclerView.setAdapter(itemAdapter);

        // Handle the add item button click
        addItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AddItemActivity.class);
                startActivity(intent);
            }
        });

        settingsButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
            startActivity(intent);
        });
    }

    private void loadItemsFromDatabase() {
        Cursor cursor = itemDatabase.getAllItems();
        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(0);
                String name = cursor.getString(1);
                String type = cursor.getString(2);
                int quantity = cursor.getInt(3);
                String description = cursor.getString(4);

                // Shorten the description for the grid view
                String shortDescription = description.length() > 30 ? description.substring(0, 30) + "..." : description;

                itemList.add(new Item(id, name, type, quantity, shortDescription));
            } while (cursor.moveToNext());
        }
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.SEND_SMS},
                    REQUEST_SMS_PERMISSION);
        }
    }

    // Method used to check if items are below a specified threshold
    // Will call sendSms() if the quantity is low enough and notifications are enabled
    private void checkItemQuantities() {
        SharedPreferences sharedPreferences = getSharedPreferences("AppSettings", MODE_PRIVATE);
        boolean notificationsEnabled = sharedPreferences.getBoolean("notificationsEnabled", false);
        int notificationThreshold = sharedPreferences.getInt("notificationThreshold", 0);
        String phoneNumber = sharedPreferences.getString("notificationPhoneNumber", "");

        if (notificationsEnabled && !phoneNumber.isEmpty()) {

            Cursor cursor = itemDatabase.getAllItems();

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    int quantity = cursor.getInt(cursor.getColumnIndexOrThrow("quantity"));
                    String itemName = cursor.getString(cursor.getColumnIndexOrThrow("name"));

                    // If the quantity is below the threshold, send an SMS notification
                    if (quantity < notificationThreshold) {
                        String message = "Alert: Item '" + itemName + "' is low on stock. Current quantity: " + quantity;
                        sendSms(phoneNumber, message);
                    }
                } while (cursor.moveToNext());

                cursor.close();
            }
        }
    }

    // Used in checkItemQuantities() method to notify user of low inventory
    private void sendSms(String phoneNumber, String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "Low stock SMS sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS sending failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        itemList.clear();
        loadItemsFromDatabase();
        itemAdapter.notifyDataSetChanged();
        checkItemQuantities();
    }
}
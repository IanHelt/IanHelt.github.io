package com.cs360.projecttwo;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {

    private Switch notificationSwitch;
    private EditText thresholdEditText, phoneNumberEditText;
    private Button backButton;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        notificationSwitch = findViewById(R.id.notificationSwitch);
        thresholdEditText = findViewById(R.id.thresholdEditText);
        phoneNumberEditText = findViewById(R.id.phoneNumberEditText);
        backButton = findViewById(R.id.backButton);

        sharedPreferences = getSharedPreferences("AppSettings", MODE_PRIVATE);

        // Load saved preferences
        boolean notificationsEnabled = sharedPreferences.getBoolean("notificationsEnabled", false);
        int notificationThreshold = sharedPreferences.getInt("notificationThreshold", 0);
        String phoneNumber = sharedPreferences.getString("notificationPhoneNumber", "");

        notificationSwitch.setChecked(notificationsEnabled);
        thresholdEditText.setText(String.valueOf(notificationThreshold));
        phoneNumberEditText.setText(phoneNumber);

        notificationSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean("notificationsEnabled", isChecked);
            editor.apply();
            Toast.makeText(SettingsActivity.this, "Notifications " + (isChecked ? "enabled" : "disabled"), Toast.LENGTH_SHORT).show();
        });

        backButton.setOnClickListener(v -> {
            String thresholdText = thresholdEditText.getText().toString();
            String phoneText = phoneNumberEditText.getText().toString();

            if (!thresholdText.isEmpty() && !phoneText.isEmpty()) {
                int threshold = Integer.parseInt(thresholdText);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putInt("notificationThreshold", threshold);
                editor.putString("notificationPhoneNumber", phoneText);
                editor.apply();

                Toast.makeText(SettingsActivity.this, "Settings saved", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(SettingsActivity.this, "Please enter a valid threshold and phone number", Toast.LENGTH_SHORT).show();
            }
            finish();
        });
    }

    // Method to send SMS
    private void sendSms(String phoneNumber, String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS Sent!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}

package com.example.demo;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/items")
public class ItemController {
    private final ItemRepository repo;
    public ItemController(ItemRepository repo) { this.repo = repo; }

    @GetMapping
    public List<ItemDto> list(@RequestParam Long userId) {
        return repo.findByUserIdOrderByNameAsc(userId).stream().map(ItemDto::from).toList();
    }
    
    @GetMapping("/{id}")
    public ItemDto getOne(@PathVariable Long id) {
        return repo.findById(id).map(ItemDto::from).orElseThrow();
    }

    @PostMapping
    public ItemDto create(@RequestBody ItemCreateDto req) {
        Item saved = repo.save(new Item(req.userId(), req.name(), req.type(), req.qty(), req.description()));
        return ItemDto.from(saved);
    }

    @PutMapping("/{id}")
    public ItemDto update(@PathVariable Long id, @RequestBody ItemCreateDto req) {
        Item i = repo.findById(id).orElseThrow();
        i.setName(req.name()); i.setType(req.type()); i.setQty(req.qty()); i.setDescription(req.description());
        return ItemDto.from(repo.save(i));
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) { repo.deleteById(id); }
}

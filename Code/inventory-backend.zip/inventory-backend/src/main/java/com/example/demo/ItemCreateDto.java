package com.example.demo;

public record ItemCreateDto(Long userId, String name, String type, Integer qty, String description) {
	
}

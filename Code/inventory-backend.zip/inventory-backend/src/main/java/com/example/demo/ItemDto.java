package com.example.demo;

public record ItemDto(Long id, Long userId, String name, String type, Integer qty, String description) {
    public static ItemDto from(Item i) {
        return new ItemDto(i.getId(), i.getUserId(), i.getName(), i.getType(), i.getQty(), i.getDescription());
    }
}

package com.example.demo;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
public class UserController {
    private final UserRepository repo;

    public UserController(UserRepository repo) {
        this.repo = repo;
    }

    /** Register a new user */
    @PostMapping
    public UserDto create(@RequestBody UserCreateDto req) {
        // TODO: Hash password before saving (for demo only)
        User saved = repo.save(new User(req.username(), req.password()));
        return UserDto.from(saved);
    }

    /** Log in existing user */
    @PostMapping("/login")
    public ResponseEntity<UserDto> login(@RequestBody UserCreateDto req) {
        User u = repo.findByUsername(req.username()).orElse(null);

        if (u == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

        if (!u.getPassword().equals(req.password())) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        return ResponseEntity.ok(UserDto.from(u));
    }

    /** Get a user by ID */
    @GetMapping("/{id}")
    public UserDto get(@PathVariable Long id) {
        User u = repo.findById(id).orElseThrow();
        return UserDto.from(u);
    }
}

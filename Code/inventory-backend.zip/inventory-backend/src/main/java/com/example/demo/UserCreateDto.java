package com.example.demo;

public record UserCreateDto(String username, String password) {}

package com.example.demo;

public record UserDto(Long id, String username) {
    public static UserDto from(User u) {
        return new UserDto(u.getId(), u.getUsername());
    }
}
